import static org.apache.commons.io.FileUtils.*;

import java.io.*;

public class Organization {

	private String white, red, green, blue, orange, yellow;

	String[][][] cube = new String[6][3][3];


	public Organization() {
		white = "#FFFFFF";
		red = "#FF0000";
		green = "#00FF00";
		blue = "#0000FF";
		orange = "#FFA500";
		yellow = "#FFFF55";
		newCube();

	}


	// Cube defined by [face][row][column] = [6][3][3]
	private void newCube() {
		for (int face = 0; face < 6; face++) {
			String color;
			switch (face) {
			case 0: // U face
				color = white;
			case 1: // F face
				color = red;
			case 2: // L face
				color = green;
			case 3: // R face
				color = blue;
			case 4: // B face
				color = orange;
			case 5: // D face
				color = yellow;
			default: // error.
				color = "000000";
			}
			for (int row = 0; row < 3; row++) {
				cube[face][row][0] = color;
				cube[face][row][1] = color;
				cube[face][row][2] = color;
			}
		}
	}


	private void func(String filename) throws IOException {
		String content = readFileToString(new File(filename));
	}


	private void Ulong() {
		String[][][] copy = cube.clone();
		// Send (1, 0, 2) to (2, 0, 2)
		copy[2][0][0] = cube[1][0][0];
		copy[2][0][1] = cube[1][0][1];
		copy[2][0][2] = cube[1][0][2];
		// Send (2, 0, 2) to (4, 0, 2)
		copy[4][0][0] = cube[2][0][0];
		copy[4][0][1] = cube[2][0][1];
		copy[4][0][2] = cube[2][0][2];
		// Send (4, 0, 2) to (3, 0, 2)
		copy[3][0][0] = cube[4][0][0];
		copy[3][0][1] = cube[4][0][1];
		copy[3][0][2] = cube[4][0][2];
		// Send (3, 0, 2) to (1, 0, 2)
		copy[1][0][0] = cube[3][0][0];
		copy[1][0][1] = cube[3][0][1];
		copy[1][0][2] = cube[3][0][2];
		// Rotate U face
		// Corners
		copy[0][0][2] = cube[0][0][0];
		copy[0][2][2] = cube[0][0][2];
		copy[0][2][0] = cube[0][2][2];
		copy[0][0][0] = cube[0][2][0];
		// Middles
		copy[0][1][2] = cube[0][0][1];
		copy[0][2][1] = cube[0][1][2];
		copy[0][1][0] = cube[0][2][1];
		copy[0][0][1] = cube[0][1][0];
	}


	private void U() {
		//
	}


	String[][][] cube_v1 = { { { white, white, white }, { white, white, white }, { white, white, white } },
			{ { red, red, red }, { red, red, red }, { red, red, red } },
			{ { green, green, green }, { green, green, green }, { green, green, green } },
			{ { blue, blue, blue }, { blue, blue, blue }, { blue, blue, blue } },
			{ { orange, orange, orange }, { orange, orange, orange }, { orange, orange, orange } },
			{ { yellow, yellow, yellow }, { yellow, yellow, yellow }, { yellow, yellow, yellow } } };

}
